document.addEventListener('DOMContentLoaded', () => {
  const app = document.getElementById('app') as HTMLDivElement
  app.innerHTML = '<h1>Welcome to web</h1>'
})