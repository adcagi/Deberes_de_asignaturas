

export function toggleTheme(button: HTMLElement, square: HTMLElement, text: HTMLElement){
    button?.addEventListener("click", () => {
        if(square!.className === "backgroundDark"){
            square!.className = "backgroundLight";
            text!.className = "textDark";
        }else{
            square!.className = "backgroundDark";
            text!.className = "textLight";
        }
    })
}