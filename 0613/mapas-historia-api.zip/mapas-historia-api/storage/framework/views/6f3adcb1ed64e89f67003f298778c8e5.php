<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Coches</h1>
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $coches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li>
            <?php echo e($c->modelo); ?>

            <?php echo e($c->marca); ?>

            <?php echo e($c->antigüedad); ?>

        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p> No hay coches</p>
        <?php endif; ?>
    </ul>
</body>
</html><?php /**PATH C:\Users\Adrian\Deberes_de_asignaturas\0613\mapas-historia-api\resources\views/coche.blade.php ENDPATH**/ ?>