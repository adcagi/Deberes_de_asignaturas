<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Animales con Clases PHP</title>
</head>
<body>
    <h1>Ejemplo de Clases en PHP con Herencia e Interfaces</h1>
    
    <?php $__currentLoopData = $animales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo => $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2><?php echo e(ucfirst($tipo)); ?>: <?php echo e($animal['nombre']); ?></h2>
        <p><?php echo e($animal['comer']); ?></p>
        <p><?php echo e($animal['hablar']); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h3>Explicación:</h3>
    <ul>
        <li><strong>Interfaz Habitable:</strong> Obliga a implementar <code>hablar()</code>.</li>
        <li><strong>Clase Animal:</strong> Base con propiedades y métodos comunes.</li>
        <li><strong>Herencia:</strong> Perro y Gato extienden Animal y heredan <code>comer()</code>.</li>
        <li><strong>Uso en Blade:</strong> PHP procesa las clases y pasa datos a la vista.</li>
    </ul>
</body>
</html><?php /**PATH C:\Users\Adrian\Deberes_de_asignaturas\0613\mapas-historia-api\resources\views/animales.blade.php ENDPATH**/ ?>