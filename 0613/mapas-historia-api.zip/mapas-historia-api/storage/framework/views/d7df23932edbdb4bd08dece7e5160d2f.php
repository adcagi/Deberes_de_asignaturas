<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

    <h1 class="mb-4">Listado de Productos</h1>

    
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-4">
            <input type="text" name="name" class="form-control"
                   placeholder="Nombre del producto"
                   value="<?php echo e(request('name')); ?>">
        </div>

        <div class="col-md-4">
            <input type="number" name="stock" class="form-control"
                   placeholder="Stock mínimo"
                   value="<?php echo e(request('stock')); ?>">
        </div>

        <div class="col-md-4">
            <button class="btn btn-primary">Filtrar</button>
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Limpiar</a>
        </div>
    </form>

    
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Stock</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td>$<?php echo e(number_format($product->price, 2)); ?></td>
                    <td><?php echo e($product->stock); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">
                        No hay productos registrados
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\Users\Adrian\Deberes_de_asignaturas\0613\mapas-historia-api\resources\views/products.blade.php ENDPATH**/ ?>