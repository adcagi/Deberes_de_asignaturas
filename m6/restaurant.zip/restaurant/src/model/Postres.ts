import Product from "./Product";

export default class Postres extends Product {

    constructor(id : number, name: string, price : number){
        super(id, name, price)
    }
}
